#��/bin/bash
dotnet BeetleX.HttpGatewayApp.dll