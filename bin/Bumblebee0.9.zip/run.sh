﻿#！/bin/bash
dotnet Bumblebee.ConsoleServer.dll