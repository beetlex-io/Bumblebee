#��/bin/bash
dotnet Bumblebee.Server.dll